for R in 1 2 3 4;
do
    for uplimit in 40 20;
    do
        for leftlimit in 60 40;
        do
            for totcheckerlimit in 1000;
            do
                newdir=R_"$R"_adduplimit_"$uplimit"_leftlimit_"$leftlimit"_totcheckerlimit_"$totcheckerlimit";
                mkdir -p $newdir
                cp plot_template.sh $newdir;
                sed "s/R_VALUE/$R/; s/UPLIMIT_VALUE/$uplimit/; s/LEFT_LIMIT/$leftlimit/; s/TOTAL_CHECKER_LIMIT/$totcheckerlimit/" template.sim100x100.C_C.py > "$newdir"/sim100x100.C_C.R-"$R"_adduplimit_"$uplimit"_leftlimit_"$leftlimit"_totcheckerlimit_"$totcheckerlimit".py
            done
        done
    done
done
