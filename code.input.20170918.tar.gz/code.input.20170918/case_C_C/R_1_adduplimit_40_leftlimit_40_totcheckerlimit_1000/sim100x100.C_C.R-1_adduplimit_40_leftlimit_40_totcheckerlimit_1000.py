

"""
continously adding checkers, random arrangement of destination,

finitively adding checkers with maximally number = total_checkers_limit 
at each step, 
add the number of checkers in the range [1, addchecker_uplimit ], 
until there is at most leftside_checker_uplimit  occupied sites on the left side 


"""


import numpy as np
import random

import sys 
import os

##################################################################


syssize = 100
R = 1
totalstep = 1000
addchecker_uplimit = 40
leftside_checker_uplimit = 40
total_checkers_limit = 1000
period_output = 1

xy2d=np.zeros((syssize, syssize), dtype=int) # index 0:syssize-1, 0:syssize-1

# init 
## use index start from 1 and exclude index 0, final len equals to total_checkers
total_checkers=0

total_addchecker_num = 0
current_addchecker_num = 0 
select_index_s = 0  # select start point x index 
select_index_e = 0  # select end point x index 
track_label_start_end={}

flogname='logging.dat'
ftrajname='traj.dat'
flog=open(flogname,'w')
ftraj=open(ftrajname, 'w')

logging={'total_checkers': 0, 'finished_checkers': 0, 'conflict_checkers':0}
for step in np.arange(1, totalstep+1): # generate 1:totalstep steps
    # init at each step
    trial_point={}
    logging['conflict_checkers'] = 0
    
    # check left side checkers
    leftside_total_checkers = xy2d[:,0].sum()

    # finitively adding checkers until the total number of added checkers reach this limit
    if total_checkers < total_checkers_limit: 
        ## generate checkers
        total_addchecker_num = random.randint(1, addchecker_uplimit)    # [1,syssize]
        current_addchecker_num = 0
        while current_addchecker_num < total_addchecker_num:
        
            # left side full, can not add more. 
            if leftside_total_checkers >= leftside_checker_uplimit:  
                break   

            # left side still has blank sites, add checkers
            select_index_s = random.randint(0,syssize-1)
            if xy2d[select_index_s,0] == 0:
                xy2d[select_index_s,0] = 1
                current_addchecker_num += 1
                curr_point = [select_index_s, 0]
                
                total_checkers += 1       
                logging['total_checkers'] += 1
                start_point = [select_index_s, 0]

                select_index_e = random.randint(0, syssize-1)
                end_point = [select_index_e, syssize-1]
        
                track_label_start_end[total_checkers] = [start_point, end_point, curr_point, []] # further you can del item from it (reach right side)
                track_label_start_end[total_checkers][3].append(curr_point)
		leftside_total_checkers += 1

    # move checkers
    # call random move, relates to s,e,neighbor in R. and when conflict, randomly one stay and another go
        
    ## remove_arrival_checkers
    for checker_label in track_label_start_end.keys():
        read_end_point = track_label_start_end[checker_label][1]
        read_curr_point = track_label_start_end[checker_label][2]
        if read_curr_point[0] == read_end_point[0] and read_curr_point[1] == read_end_point[1]:
            #print 'ok, reach destination!'
            xy2d[read_end_point[0], read_end_point[1]] = 0
            ### before del this checker, print its trajectory
            for istep, icoorxy in enumerate(track_label_start_end[checker_label][3]): 
                ftraj.write("%d %d %d %d\n" % (checker_label, istep+1, icoorxy[0], icoorxy[1]))
            ### del checker
            del track_label_start_end[checker_label]
            logging['finished_checkers'] += 1

    ## update_position_trial
    for checker_label in track_label_start_end.keys():
        checker_position_info = track_label_start_end[checker_label]
        start_point = checker_position_info[0]
        end_point = checker_position_info[1]
        curr_point = checker_position_info[2]
        
        ### search the four pos to see if blank, if blank, randomly choose one with constraint (Metropolis) from b, e, neighbor in R.
        ### adjacent blank site lookup
        adjacent_sites = {0:[], 1:[]}  #init for each checker
        direction={       'up':[ [curr_point[0]+1, curr_point[1]], curr_point[0]+1 < syssize], 
                       'right':[ [curr_point[0], curr_point[1]+1], curr_point[1]+1 < syssize], 
                        'down':[ [curr_point[0]-1, curr_point[1]], curr_point[0]-1 > -1,    ], 
                        'left':[ [curr_point[0], curr_point[1]-1], curr_point[1]-1 > -1,    ] 
                  }
        if direction['up'][1]: 
            adjacent_sites[ xy2d[curr_point[0]+1, curr_point[1]] ].append([ curr_point[0]+1, curr_point[1] ])
        if direction['right'][1]: 
            adjacent_sites[ xy2d[curr_point[0], curr_point[1]+1] ].append([ curr_point[0], curr_point[1]+1 ])
        if direction['down'][1]: 
            adjacent_sites[ xy2d[curr_point[0]-1, curr_point[1]] ].append([ curr_point[0]-1, curr_point[1] ])
        if direction['left'][1]: 
            adjacent_sites[ xy2d[curr_point[0], curr_point[1]-1] ].append([ curr_point[0], curr_point[1]-1 ])
        if adjacent_sites[0]:   # available blank site(s)

            
            #### get list that includes current point, and blank adjacent point(s)
            anal_point_list = []
            anal_point_list.append(curr_point)  # xy2dvalue = 1
            for point in adjacent_sites[0]:
               anal_point_list.append(point)    # xy2dvalue = 0

            #### search neighborhood (radius R) that exclude points in anal_point_list
            neighborhood={0:[], 1:[]} 
            for i in range(curr_point[0]-R, curr_point[0]+R+1): 
                for j in range(curr_point[1]-R, curr_point[1]+R+1): 
                    if i >= 0 and i < syssize and j >= 0 and j < syssize: 
                        distance = abs(i-curr_point[0])+abs(j-curr_point[1])
                        if distance <= R and [i,j] not in anal_point_list:  
                            neighborhood[xy2d[i,j]].append([i,j])                       
            
            #### calc the energy of points on anal_point_list for further determination of stay or move
            point_energy={}
            for anal_point in anal_point_list:
                distance_anal_to_end = abs(end_point[0] - anal_point[0]) + abs(end_point[1] - anal_point[1])

                vector_anal_to_neighbor_occupied = []
                for neighbor_point in neighborhood[1]:  # occupied sites
                    vector_anal_to_neighbor_occupied.append([neighbor_point[0] - anal_point[0], neighbor_point[1] - anal_point[1]])
                energy_anal_to_neighbor_occupied = 0
                for vector in vector_anal_to_neighbor_occupied:
                    energy_anal_to_neighbor_occupied += R - ( abs(vector[0]) + abs(vector[1]) )

                #vector_anal_to_neighbor_blank = []
                #for neighbor_point in neighborhood[0]:  # blank sites
                #    vector_anal_to_neighbor_blank.append([neighbor_point[0] - anal_point[0], neighbor_point[1] - anal_point[1]])
                ##### addition_blank_point_list
                #addition_blank_point_list = []
                #for point in anal_point_list:
                #    if point[0] != anal_point[0] and point[1] != anal_point[1]:
                #        addition_blank_point_list.append(point)
                #for neighbor_point in addition_blank_point_list:  # blank sites
                #    vector_anal_to_neighbor_blank.append([neighbor_point[0] - anal_point[0], neighbor_point[1] - anal_point[1]])
                energy_anal_to_neighbor_blank = 0
                #for vector in vector_anal_to_neighbor_blank:
                #    energy_anal_to_neighbor_blank += -1 * (R - ( abs(vector[0]) + abs(vector[1]) ))

                #### go right (start -> end direction) is preferred
                energy_bias = 0
                #if anal_point[0] == curr_point[0] and anal_point[1] == curr_point[1]+1: 
                #    energy_bias = -1
                #else:
                #    energy_bias = 0
                
                point_energy[tuple(anal_point)] = 1 * distance_anal_to_end + energy_anal_to_neighbor_occupied + energy_anal_to_neighbor_blank + energy_bias

            mini_energy = point_energy[tuple(anal_point_list[0])]
            for energy in point_energy.values():
                if  mini_energy > energy:
                    mini_energy = energy

            #### get dict energy -> anal points (the following block is still effective when >= two points have the same energy) 
            inv_point_energy = {}  
            for energy in point_energy.values():
                inv_point_energy[energy] = []
            for point in point_energy.keys():
                energy = point_energy[point]
                inv_point_energy[energy].append(list(point))

            #### select the point as trial site, which has minimum energy with destination and neighbor in R
            ##### Q: further fluctuation maybe introduced here, not to select mini_energy at each time
            select_trial_point_list = inv_point_energy[mini_energy]
            if len(select_trial_point_list) == 1:
                select_trial_point = select_trial_point_list[0]
            elif len(select_trial_point_list) > 1:
                select_trial_point = random.sample(select_trial_point_list, 1)[0]
            else:
                raise ValueError

            trial_point[checker_label] = select_trial_point


    ## prepare for update_position_action
    inv_trial_point = {}    # inverse, value (ponit xy) -> list of keys (labels)
    for coorxy in trial_point.values():
        inv_trial_point[tuple(coorxy)]=[]       
    for label in trial_point.keys():
        coorxy = trial_point[label]
        inv_trial_point[tuple(coorxy)].append(label)
    
    ## update_position_action
    for coorxy in inv_trial_point.keys():            
        label = inv_trial_point[coorxy]
        ### determine which label to move with this coorxy
        ### detect conflict trial moves
        if len(label) > 1:
            select_move_label = random.sample(label,1)[0] 
            logging['conflict_checkers'] += len(label)-1
        elif len(label) == 1:
            select_move_label = label[0]
        
        ### now really update pos after detecting conflicts
        departure_point = track_label_start_end[select_move_label][2]
        track_label_start_end[select_move_label][2] = list(coorxy)
        xy2d[departure_point[0], departure_point[1]] = 0
        xy2d[coorxy[0], coorxy[1]] = 1

    ## update the traj data for each checker
    for checker_label in track_label_start_end.keys():
        curr_point = track_label_start_end[checker_label][2]
        track_label_start_end[checker_label][3].append(curr_point)
        
    ## print checkers and output pictures
    if step % period_output == 0:
        foutname='snapshot.dat'
        f=open(foutname,'w')
        xy2dlist=xy2d.tolist()
        for i in range(xy2d.shape[0]):
            for j in range(xy2d.shape[1]):
                f.write('%d %d %d\n' % (i, j, xy2dlist[i][j]))
        f.close()
        
        foutname2='distribution_up-down.dat'
        f=open(foutname2,'w')
        for i in range(xy2d.shape[0]):
            f.write('%d %d\n' % (i, xy2d[i,:].sum()))
        f.close()

        foutname3='distribution_left-right.dat'
        f=open(foutname3,'w')
        for j in range(xy2d.shape[1]):
            f.write('%d %d\n' % (j, xy2d[:,j].sum()))
        f.close()

        os.popen('/bin/bash plot_template.sh'+' '+str(foutname)+' '+str(foutname2)+' '+str(foutname3)+' '+str(step))

        flog.write('%d %d %d %d\n' % (step, logging['total_checkers'], logging['finished_checkers'], logging['conflict_checkers']))

flog.close()
ftraj.close()





