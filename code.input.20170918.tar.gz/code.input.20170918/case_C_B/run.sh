for R in 1 2 3 4 5;
do
    for uplimit in 40 20;
    do
        for leftlimit in 60 40;
        do
            newdir=R_"$R"_adduplimit_"$uplimit"_leftlimit_"$leftlimit";
            mkdir -p $newdir
            cp plot_template.sh $newdir;
            sed "s/R_VALUE/$R/; s/UPLIMIT_VALUE/$uplimit/; s/LEFT_LIMIT/$leftlimit/" template.sim100x100.C_B.py > "$newdir"/sim100x100.C_B.R-"$R"_adduplimit_"$uplimit"_leftlimit_"$leftlimit".py
        done
    done
done
