
f1=$1
f2=$2
f3=$3
n=$4

gnuplot << EOF
set term png
set output 'view_$n.png'
set xrange [0:100]
set yrange [0:100]
unset colorbox
set xlabel 'y'
set ylabel 'x'
p '$f1' u 2:1:3 w image
q
EOF

gnuplot << EOF
set term png
set output 'distri_up-down_$n.png'
set xrange [0:100]
set yrange [0:100]
set xlabel 'up-down'
set ylabel 'number of occupied sites'
p '$f2' u 1:2 w boxes
q
EOF

gnuplot << EOF
set term png
set output 'distri_left-right_$n.png'
set xrange [0:100]
set yrange [0:100]
set xlabel 'left-right'
set ylabel 'number of occupied sites'
p '$f3' u 1:2 w boxes
q
EOF



