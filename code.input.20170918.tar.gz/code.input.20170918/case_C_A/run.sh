for R in 1 2 3 4 5;
do
    newdir=R_"$R";
    mkdir -p $newdir
    cp plot_template.sh $newdir;
    sed "s/R_VALUE/$R/" template.sim100x100.C_A.py > "$newdir"/sim100x100.C_A.R-"$R".py
done
